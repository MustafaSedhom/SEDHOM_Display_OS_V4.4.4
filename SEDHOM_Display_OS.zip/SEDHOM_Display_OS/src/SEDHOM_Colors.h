#ifndef SEDHOM_COLORS
#define SEDHOM_COLORS
//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
// New color definitions.  thanks to Bodmer
#define BLACK       0x0000      /*   0,   0,   0 */
#define NAVY        0x000F      /*   0,   0, 128 */
#define DARKGREEN   0x03E0      /*   0, 128,   0 */
#define DARKCYAN    0x03EF      /*   0, 128, 128 */
#define MAROON      0x7800      /* 128,   0,   0 */
#define PURPLE      0x780F      /* 128,   0, 128 */
#define OLIVE       0x7BE0      /* 128, 128,   0 */
#define LIGHTGREY   0xC618      /* 192, 192, 192 */
#define DARKGREY    0x7BEF      /* 128, 128, 128 */
#define BLUE        0x001F      /*   0,   0, 255 */
#define GREEN       0x07E0      /*   0, 255,   0 */
#define CYAN        0x07FF      /*   0, 255, 255 */
#define RED         0xF800      /* 255,   0,   0 */
#define MAGENTA     0xF81F      /* 255,   0, 255 */
#define YELLOW      0xFFE0      /* 255, 255,   0 */
#define WHITE       0xFFFF      /* 255, 255, 255 */
#define ORANGE      0xFDA0      /* 255, 180,   0 */
#define GREENYELLOW 0xB7E0      /* 180, 255,   0 */
#define PINK        0xFC9F      /* 255, 192, 203 */
/////////////////////////////end colors//////////////////////////////
#define black       BLACK    
#define navy        NAVY    
#define darkgary    DARKGREEN   
#define darkcyan    DARKCYAN  
#define maroon      MAROON     
#define purple      PURPLE    
#define olive       OLIVE    
#define lightgrey   LIGHTGREY  
#define darkgrey    DARKGREY   
#define blue        BLUE       
#define green       GREEN 
#define cyan        CYAN      
#define red         RED       
#define magenta     MAGENTA   
#define yellow      YELLOW    
#define white       WHITE     
#define orange       ORANGE      
#define greenyellow GREENYELLOW 
#define pink        PINK 
/////////////////////////////end colors//////////////////////////////
#define Black       BLACK    
#define Navy        NAVY    
#define DarkGary    DARKGREEN   
#define DarkCyan    DARKCYAN  
#define Maroon      MAROON     
#define Purple      PURPLE    
#define Olive       OLIVE    
#define LightGrey   LIGHTGREY  
#define DarkGrey    DARKGREY   
#define Blue        BLUE       
#define Green       GREEN 
#define Cyan        CYAN      
#define Red         RED       
#define Magenta     MAGENTA   
#define Yellow      YELLOW    
#define White       WHITE     
#define Orange       ORANGE      
#define GreenYellow GREENYELLOW 
#define Pink        PINK 
/////////////////////////////end colors//////////////////////////////
#define Color_Black       BLACK    
#define Color_Navy        NAVY    
#define Color_DarkGary    DARKGREEN   
#define Color_DarkCyan    DARKCYAN  
#define Color_Maroon      MAROON     
#define Color_Purple      PURPLE    
#define Color_Olive       OLIVE    
#define Color_LightGrey   LIGHTGREY  
#define Color_DarkGrey    DARKGREY   
#define Color_Blue        BLUE       
#define Color_Green       GREEN 
#define Color_Cyan        CYAN      
#define Color_Red         RED       
#define Color_Magenta     MAGENTA   
#define Color_Yellow      YELLOW    
#define Color_White       WHITE     
#define Color_Orange       ORANGE      
#define Color_GreenYellow GREENYELLOW 
#define Color_Pink        PINK 
/////////////////////////////end colors//////////////////////////////
//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
#endif // !SEDHOM_COLORS